共通CSSを分離するときに style.css を置くフォルダです。現在の index.html は単独で動作します。
