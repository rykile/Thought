将来追加するページ（about.html / thoughts.html / updates.html など）を置くフォルダです。必要になった時点で作成してください。
